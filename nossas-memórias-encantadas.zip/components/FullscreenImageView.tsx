
import React, { useEffect, useRef } from 'react';
import { MemoryImage } from '../constants';

interface FullscreenImageViewProps {
  image: MemoryImage | null;
  onClose: () => void;
}

const FullscreenImageView: React.FC<FullscreenImageViewProps> = ({ image, onClose }) => {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    
    // Focus trapping could be added here for more robust accessibility
    // For simplicity, we'll focus the modal itself or the close button
    if (modalRef.current) {
        const closeButton = modalRef.current.querySelector('button');
        if (closeButton) {
            closeButton.focus();
        } else {
            modalRef.current.focus();
        }
    }


    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  if (!image) {
    return null;
  }

  const handleOverlayClick = (event: React.MouseEvent<HTMLDivElement>) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  return (
    <div
      className="fullscreen-modal-overlay"
      onClick={handleOverlayClick}
      role="dialog"
      aria-modal="true"
      aria-labelledby="fullscreen-image-title"
      aria-describedby="fullscreen-image-desc"
      tabIndex={-1} // Make the overlay itself focusable for escape key
      ref={modalRef}
    >
      <div className="fullscreen-modal-content">
        <button
          className="fullscreen-modal-close-button"
          onClick={onClose}
          aria-label="Fechar visualização da imagem"
        >
          &times;
        </button>
        <img src={image.src} alt={image.alt} id="fullscreen-image-desc" />
        {image.title && (
          <h2 id="fullscreen-image-title" className="fullscreen-modal-title">
            {image.title}
          </h2>
        )}
      </div>
    </div>
  );
};

export default FullscreenImageView;
