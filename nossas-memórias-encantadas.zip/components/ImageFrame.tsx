
import React, { useState } from 'react';
import { MemoryImage } from '../constants';

interface ImageFrameProps {
  image: MemoryImage;
  onImageSelect: (image: MemoryImage) => void; // New prop
}

const ImageFrame: React.FC<ImageFrameProps> = ({ image, onImageSelect }) => {
  const [isBurning, setIsBurning] = useState(false);

  const handleImageClick = () => {
    if (isBurning) return; 

    setIsBurning(true);
    setTimeout(() => {
      setIsBurning(false);
    }, 1500); 
    
    onImageSelect(image); // Call the new prop function
  };

  return (
    <div 
      className="group relative overflow-hidden rounded-lg shadow-lg 
                 bg-gradient-to-br from-stone-800 to-stone-900 p-1.5
                 border border-amber-700/50 hover:border-amber-500
                 transition-all duration-500 ease-in-out transform hover:scale-105 cursor-pointer"
      onClick={handleImageClick}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleImageClick(); }}
      role="button"
      tabIndex={0}
      aria-label={`Memória: ${image.alt}. Clique para animação de fogo e para ver em tela cheia.`}
    >
      <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-300 z-10"></div>
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0
                      bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))]
                      from-amber-400/30 via-transparent to-transparent blur-xl">
      </div>
      
      <div className={`relative bg-stone-700 text-slate-300 flex items-center justify-center p-1 rounded-md shadow-inner aspect-[4/3] ${isBurning ? 'image-burn-effect' : ''}`}>
        <img
          src={image.src}
          alt={image.alt}
          className="w-full h-full object-cover rounded-sm"
          loading="lazy"
        />
      </div>
      <div 
        className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent 
                   opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out z-20"
      >
        <h3 className="text-amber-200 font-cinzel text-sm md:text-md font-semibold text-center truncate">
          {image.title} {/* Emoji title */}
        </h3>
      </div>
      
      {/* Subtle hover sparkle effect - pseudo-randomly positioned */}
      {[...Array(3)].map((_, i) => (
        <div
          key={`hover-sparkle-${i}`}
          className={`absolute w-1 h-1 bg-amber-300 rounded-full animate-pulse
                        opacity-0 group-hover:opacity-70 transition-opacity duration-700 delay-${i * 100}`}
          style={{
            top: `${20 + Math.random() * 60}%`,
            left: `${20 + Math.random() * 60}%`,
            animationDuration: `${1.5 + Math.random()}s`,
          }}
        ></div>
      ))}

      {/* Click-triggered Fire Animation Elements */}
      {isBurning && (
        <>
          <div className="flame-overlay"></div>
          {[...Array(7)].map((_, i) => ( // 7 fire particles
            <div
              key={`fire-particle-${i}`}
              className="fire-particle"
              style={{
                left: `${10 + Math.random() * 80}%`, 
                animationDuration: `${0.8 + Math.random() * 0.7}s`, 
                animationDelay: `${Math.random() * 0.4}s`, 
              }}
            ></div>
          ))}
        </>
      )}
    </div>
  );
};

export default ImageFrame;
