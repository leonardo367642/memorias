
export interface MemoryImage {
  id: number;
  src: string;
  alt: string;
  title: string;
}

export const MEMORY_IMAGES: MemoryImage[] = [
  {
    id: 1,
    src: 'https://i.imgur.com/h5cRnPu.jpeg', 
    alt: 'Nossa primeira memória especial', 
    title: '⚡️', 
  },
  {
    id: 2,
    src: 'https://i.imgur.com/xKaprhA.jpeg', 
    alt: 'Nossa segunda aventura mágica', 
    title: '🦉', 
  },
  {
    id: 3,
    src: 'https://i.imgur.com/Cuzf1Ri.jpeg', 
    alt: 'Nossa terceira recordação querida', 
    title: '🧙', 
  },
  {
    id: 4,
    src: 'https://i.imgur.com/VRdIm6F.jpeg',
    alt: 'Nossa quarta lembrança marcante', 
    title: '📜', 
  },
  {
    id: 5,
    src: 'https://i.imgur.com/XEAMntK.jpeg', 
    alt: 'Descrição da sua quinta memória',
    title: '🔮',
  },
  {
    id: 6,
    src: 'https://i.imgur.com/CprqD3s.jpeg',
    alt: 'Descrição da sua sexta memória',
    title: '✨',
  },
];

export const HEADER_TEXT = "Nossas Memórias";
export const FOOTER_TEXT = "Você é minha Horcrux.";
