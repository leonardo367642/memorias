
import React, { useState, useEffect } from 'react';
import ImageFrame from './components/ImageFrame';
import FullscreenImageView from './components/FullscreenImageView';
import { MEMORY_IMAGES, HEADER_TEXT, FOOTER_TEXT, MemoryImage } from './constants';

const App: React.FC = () => {
  const [footerVisible, setFooterVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState<MemoryImage | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFooterVisible(true);
    }, 1500); // Delay for the fade-in effect
    return () => clearTimeout(timer);
  }, []);

  const handleImageSelect = (image: MemoryImage) => {
    setSelectedImage(image);
    setIsModalOpen(true);
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    // Small delay to allow fade-out animation of modal if any
    setTimeout(() => {
        setSelectedImage(null);
         // Restore body scroll
        document.body.style.overflow = '';
    }, 300); // Match modal fade-out duration if applicable
  };

  return (
    <div className="min-h-screen bg-black text-slate-200 p-4 md:p-8 flex flex-col items-center selection:bg-amber-500 selection:text-slate-900">
      <header className="text-center my-8 md:my-12 relative">
        <h1 className="font-cinzel text-4xl sm:text-5xl md:text-6xl text-amber-300 tracking-wider">
          {HEADER_TEXT}
        </h1>
        <div className="absolute -top-2 -left-4 w-12 h-12 md:w-16 md:h-16 bg-amber-400/30 rounded-full blur-xl animate-pulse"></div>
        <div className="absolute -bottom-2 -right-4 w-10 h-10 md:w-14 md:h-14 bg-purple-400/30 rounded-full blur-xl animate-pulse delay-500"></div>
        <p className="text-slate-400 mt-2 text-sm md:text-base font-lora">Se eu fosse produzir um Patrono, você seria meu pensamento feliz.</p>
      </header>

      <main className="w-full max-w-6xl px-2 md:px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {MEMORY_IMAGES.map((image) => (
            <ImageFrame 
              key={image.id} 
              image={image}
              onImageSelect={handleImageSelect} 
            />
          ))}
        </div>
      </main>

      <footer className="mt-12 md:mt-20 py-8 text-center">
        <p
          className={`font-cinzel text-2xl sm:text-3xl md:text-4xl text-amber-400 
                      transition-all duration-1000 ease-in-out
                      ${footerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
        >
          {FOOTER_TEXT}
        </p>
        <div className={`mt-2 h-0.5 w-24 bg-amber-600 mx-auto rounded-full
                        transition-all duration-1000 ease-in-out delay-300
                        ${footerVisible ? 'opacity-70 scale-x-100' : 'opacity-0 scale-x-0'}`}>
        </div>
        <p
          className={`mt-8 text-xs text-slate-500 font-lora
                      transition-all duration-1000 ease-in-out delay-500
                      ${footerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`}
          aria-label="Autor do site"
        >
          Leonardo Assunção
        </p>
      </footer>
      
      {isModalOpen && selectedImage && (
        <FullscreenImageView image={selectedImage} onClose={handleCloseModal} />
      )}
    </div>
  );
};

export default App;
